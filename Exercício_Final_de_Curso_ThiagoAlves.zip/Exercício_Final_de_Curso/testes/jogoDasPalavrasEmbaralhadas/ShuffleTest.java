package jogoDasPalavrasEmbaralhadas;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ShuffleTest {
	
	//==============================================================================
	// o teste demonstra no console uma escolha aleat�ria do banco de palavras
	// sendo imprimidos a palavra correta e ela embaralhada. N�o usei assertEquals()
	// pela imprevisibilidade da palavra escolhida e do embaralhamento shuffle.
	//==============================================================================

	@Test
	void testEmbaralhamento() {
		Shuffle sff = new Shuffle();
		sff.embaralhar();
		System.out.println(" A palavra escolhida aleat�riamente foi: " + sff.getPalavraCorreta());
		System.out.println(" Esta palavra embaralhada por Shuffle � : " + sff.getPalavraEmbaralhada());
	}

}
