package jogoDasPalavrasEmbaralhadas;

import java.util.ArrayList;
import java.util.Collections;

//================================================================
// Classe que implementa Embaralhador.
// As implementa��es de embaralhador devem conter algoritmos para
// o embaralhamento de palavras.
//================================================================

public class Reverse implements Embaralhador {
	
	private BancoDepalavras bp = new BancoDepalavras();
	private String palavraCorreta;
	private String palavraEmbaralhada;
	
	//==============================================================
	// esta implementa��o embaralha invertendo as letras da palavra,
	// escrevendo elas de tr�s para frente.
	//==============================================================
	
	public void embaralhar() {
		palavraCorreta = bp.getPalavra();
		palavraEmbaralhada = palavraCorreta;
		char[] letras = palavraEmbaralhada.toCharArray();
		ArrayList<Character> listaDeLetras = new ArrayList<Character>();
		for (int i = 0; i < letras.length; i++) {
			listaDeLetras.add(letras[i]);
		}
		Collections.reverse(listaDeLetras);
		char[] letrasEmbaralhadas = new char[letras.length];
		for (int i = 0; i < letras.length; i++) {
			letrasEmbaralhadas[i] = listaDeLetras.get(i);
		}
		palavraEmbaralhada = new String(letrasEmbaralhadas);
	}

	@Override
	public String getPalavraCorreta() {		
		return palavraCorreta;
	}

	@Override
	public String getPalavraEmbaralhada() {
		return palavraEmbaralhada;
	}
}
