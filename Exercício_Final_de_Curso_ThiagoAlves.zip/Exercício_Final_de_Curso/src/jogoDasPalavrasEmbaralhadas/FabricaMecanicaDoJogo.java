package jogoDasPalavrasEmbaralhadas;

public class FabricaMecanicaDoJogo {
	
	private MecanicaDoJogo mec;
	
	//=======================================================================================
	// lista que configura a mec�nica de acordo com a escolha do usu�rio na classe Principal.
	//=======================================================================================
	
	protected void setMecanica(int i) {
		switch (i) {
		case 1:
			mec = new Mecanica1();
			break;
		case 2:
			mec = new Mecanica2();
			break;
		default:
			System.out.println("Informa��o inv�lida. Digite 1 ou 2.");
		}
	}
	
	//=================================================
	// retorna a MecanicaDoJogo que deve ser utilizada.
	//=================================================

	protected MecanicaDoJogo getMecanica() {
		return mec;
	}	

}
