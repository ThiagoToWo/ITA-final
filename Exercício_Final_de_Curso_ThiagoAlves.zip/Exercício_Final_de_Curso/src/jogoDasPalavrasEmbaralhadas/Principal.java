package jogoDasPalavrasEmbaralhadas;

import java.util.Scanner;

//==================================================================================
// representa a classe com o m�todo main(). � essa classe que � respons�vel por ler
// a entrada do usu�rio e por imprimir as informa��es no console. Nenhuma outra
// classe pode imprimir ou ler do console.
//==================================================================================

public class Principal {

	public static void main(String[] args) {		
		
		Scanner input = new Scanner(System.in);
		FabricaMecanicaDoJogo fm = new FabricaMecanicaDoJogo();
		int numDaPergunta = 0;
		
		//====================================================
		// informa��es iniciais e escolha da mec�nica de jogo.
		//====================================================
		
		System.out.println("Jogo das Palavras Embaralhadas");		
		System.out.println("=======================================================================");		
		System.out.println("(1) Prova de resist�ncia: voc� tem 3 chances de errar. Acerte o m�ximo\n"
				           + "    de palavras que voc� conseguir");
		System.out.println("(2) Corrida dos dez: sem errar, acerte a sequ�ncia de 10 palavras");
		System.out.println("=======================================================================");		
		System.out.print("Escolha sua modalidade de jogo (digite o n�mero dela) --> ");
		
		//============================================
		// configura��o e captura da mec�nica do jogo.
		//============================================
		
		int modalidade = input.nextInt();
		fm.setMecanica(modalidade);
		
		//==========================================================================================
		// A classe Principal deve recuperar a inst�ncia de MecanicaDoJogo de FabricaMecanicaDoJogo
		// e n�o pode conter nenhuma refer�ncia direta a uma das implementa��es, apenas a interface.
		//==========================================================================================
		
		MecanicaDoJogo mecanica = fm.getMecanica();
		
		boolean fimDoJogo = false;
		
		//==============
		// iniciar jogo.
		//==============
		
		while (fimDoJogo  == false) {	
			
			//=======================================================================================
			// O importante � que independente do funcionamento [da implementa��o de MecanicaDoJogo],
			// a classe Principal dever� interagir com ela da mesma forma.
			//=======================================================================================
			
			String palavraEmbaralhada = mecanica.getPalavraEmbaralhada();
			System.out.print(++numDaPergunta + ". ");
			System.out.print("Que palavra � " + palavraEmbaralhada + "? ");
			String palpite = input.next();
			boolean segueOJogo = mecanica.palavraCorreta(palpite);
			if (segueOJogo == false) {
				int numAcertos = mecanica.numeroDeAcertos();
				System.out.println("Fim do jogo! A quantidade de acertos foi " + numAcertos);
				fimDoJogo = true;
				input.close();
			} 
		}
	}

}
