package jogoDasPalavrasEmbaralhadas;

//=============================================================================
// interface que representa classes repons�veis por receber uma palavra e
// retornar ela embaralhada. Pelo menos duas implementa��es dever�o ser feitas.
//=============================================================================

public interface Embaralhador {	
	
	void embaralhar();	
	
	String getPalavraCorreta();

	String getPalavraEmbaralhada();
}
