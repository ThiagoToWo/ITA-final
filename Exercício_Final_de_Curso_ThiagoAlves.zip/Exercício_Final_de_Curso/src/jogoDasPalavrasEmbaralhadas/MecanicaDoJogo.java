package jogoDasPalavrasEmbaralhadas;

//======================================================================
//interface que representa o andamento e a l�gica do jogo. � respons�vel
// por ditar o andamento do jogo.
//======================================================================

public interface MecanicaDoJogo {
	
	String getPalavraEmbaralhada();

	boolean palavraCorreta(String palpite);		

	int numeroDeAcertos();
	
}
