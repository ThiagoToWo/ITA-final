package jogoDasPalavrasEmbaralhadas;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

//=====================================================================
// classe que possui um m�todo que retorna uma palavra retirada
// aleat�riamente de uma lista de palavras lida a partir de um arquivo.
//=====================================================================

public class BancoDepalavras {
	
	private String palavra;
	
	private void lerPalavra() {
		Scanner leitor;
		try {
			leitor = new Scanner( new File("listaDePalavras.txt"));
			int rnd = new Random().nextInt(20) + 1;
			int i = 1;
			do {
				palavra = leitor.next();
				i++;
			} while (i <= rnd);
			leitor.close();
		} catch (FileNotFoundException e) {			
			e.printStackTrace();
		}		
	}
	
	//============================================================================
	// o m�todo que retorna a palavra antes faz uso do m�todo private lerPalavra()
	// que l� uma lista de palavras at� uma posi��o aleat�ria e retorna a �ltima.
	//============================================================================
	
	public String getPalavra() {
		this.lerPalavra();		
		return palavra;
	}

}
