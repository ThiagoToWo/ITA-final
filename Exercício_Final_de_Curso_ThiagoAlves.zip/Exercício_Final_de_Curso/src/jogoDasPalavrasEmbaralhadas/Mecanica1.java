package jogoDasPalavrasEmbaralhadas;

//================================================================================================
// Classe que implementa MecanicaDoJogo.
// Ela que vai dizer se o jogo acabou ou n�o, se o usu�rio acertou a palavra ou n�o, se o usu�rio
// pode tentar acertar a palavra novamente e qual foi a pontua��o final do jogador.
//================================================================================================

public class Mecanica1 implements MecanicaDoJogo {
	
	private FabricaEmbaralhador fe = new FabricaEmbaralhador();		
	private Embaralhador emb;
	private int numAcertos = 0;
	private int numErros = 0;
	
	//====================================================================================
	// m�todo que retorna uma palavra embaralhada para ser impressa pela classe Principal.
	//====================================================================================
	
	@Override
	public String getPalavraEmbaralhada() {
		
		//=========================================================================
		// as implementa��es de MecanicaDoJogo devem recuperar os embaralhadores de
		// FabricaEmbaralhadores e tamb�m n�o pode conter nenhuma refer�ncia direta
		// a implementa��es de Embaralhador, apenas a interface.
		//=========================================================================
		
		emb = fe.getEmbaralhadorAleatorio();
		emb.embaralhar();
		String palavraEmbaralhada = emb.getPalavraEmbaralhada();
		return palavraEmbaralhada;
	}
	
	//=====================================================================================
	// m�todo que confere se o palpite do usu�rio est� correto. Nesta implementa��o retorna
	// true at� o usu�rio cometer 3 erros. Ou seja, o jogo continua indefinidamente at� o
	// terceiro erro.
	//=====================================================================================
	
	@Override
	public boolean palavraCorreta(String palpite) {	
		boolean continua = false;
		String palavraCorreta = emb.getPalavraCorreta();
		if (palpite.equals(palavraCorreta)) {
			numAcertos++;
			continua = true;
		} else {
			numErros++;			
			if (numErros == 3) {
				continua = false;				
			} else {
				continua = true;
			}
		}
		return continua;		
	}

	//========================================================================================
	// m�todo que retorna o n�mero de acertos para a contagem de pontos pela classe Principal.
	//========================================================================================
	
	@Override
	public int numeroDeAcertos() {
		return numAcertos;
	}

}
