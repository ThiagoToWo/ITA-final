package jogoDasPalavrasEmbaralhadas;

import java.util.Random;

public class FabricaEmbaralhador {
	
	protected Embaralhador[] embaralhadores = {new Shuffle(), new Reverse()};
	
	//=============================================
	// possui um m�todo que retorna um embaralhador
	// aleat�riamente.
	//=============================================
	
	public Embaralhador getEmbaralhadorAleatorio() {
		int rnd = new Random().nextInt(embaralhadores.length);
		return embaralhadores[rnd];
	}

}
